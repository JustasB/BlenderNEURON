from blenderneuron.blender.views.groupobjectview import GroupObjectView
from blenderneuron.blender.views.cellobjectview import CellObjectView
from blenderneuron.blender.views.sectionobjectview import SectionObjectView
from blenderneuron.blender.views.jsonview import JsonView
from blenderneuron.blender.utils import remove_prop_collection_item, COLOR_RAMP_NAME
from blenderneuron.rootgroup import *
from blenderneuron.blender.views.vectorconfinerview import VectorConfinerView
import bpy
from blenderneuron.datablocknames import get_registry, entity_key
from blenderneuron.blender.views.curvecontainer import CurveContainer
from fnmatch import fnmatch
from blenderneuron.utils import serialize
import os

class BlenderRootGroup(RootGroup):

    @property
    def ui_group(self):
        return self.node.ui_properties.groups[self.name]

    @property
    def color_ramp_material(self):
        if hasattr(self, 'color_ramp_key'):
            return get_registry().resolve(self.color_ramp_key)
        return bpy.data.materials.get(self.color_ramp_material_name)

    def __init__(self, name, node):
        super(BlenderRootGroup, self).__init__()

        self.selected = True
        self.name = name
        self.node = node

        self.view = None

        # Group display properties
        self.smooth_sections = True
        self.spherize_soma_if_DeqL=True
        self.as_lines=False
        self.segment_subdivisions=2
        self.circular_subdivisions=6
        self.default_brightness = 1.0

        # Animation properties
        self.animate_brightness = True
        self.max_brightness = 5
        self.animate_color = True
        self.animation_range_low = -85
        self.animation_range_high = 20
        self.simplification_epsilon = 0.1

        self.state = 'new'
        self.root_filter = '*'

        # Default: Pale yellowish green
        self.color_ramp_material_name = self.create_color_ramp_material([0.14, 0.67, 0.02, 1.0])

    @property
    def default_color(self):
        return self.color_ramp_material.node_tree.nodes[COLOR_RAMP_NAME].color_ramp.elements[0].color

    @default_color.setter
    def default_color(self, value):
        self.color_ramp_material.node_tree.nodes[COLOR_RAMP_NAME].color_ramp.elements[0].color = value

    def create_color_ramp_material(self, default_color):
        name = self.name + '_color_ramp'

        registry = get_registry()
        key = self.color_ramp_key = entity_key('materials', 'color-ramp', name, self.name)
        existing = registry.resolve(key)
        if existing is not None:
            return existing.name
        mat = registry.create(key, bpy.data.materials.new)
        mat.use_nodes = True
        CurveContainer.identify_node_tree(mat, registry)
        mat.use_fake_user = True

        node = mat.node_tree.nodes.new('ShaderNodeValToRGB')

        node.color_ramp.elements[0].color = default_color
        node.color_ramp.elements[-1].color = [1] * 4  # All white

        return mat.name


    def highlight(self):
        self.node.ui_properties.groups_index = self.ui_group.index

    def from_full_NEURON_group(self, nrn_group):

        # Update each group root with the NRN root
        for nrn_root in nrn_group["roots"]:

            name = nrn_root["name"]

            if name not in self.roots:
                bpy.ops.blenderneuron.get_cell_list_from_neuron()

            self.roots[name].from_full_NEURON_section_dict(nrn_root)

        if "activity" in nrn_group:
            self.activity.from_dict(nrn_group["activity"])

            # Set activity times from the group time
            for root in self.roots.values():
                self.set_activity_times(root, self.activity.times)
                self.simplify_activity(root)
                
        else:
            self.clear_activity()
            
        self.state = 'imported'

    def set_activity_times(self, root, times):
        """
        Iteratively sets the activity times for each node starting from the root node.

        :param root: The root node whose activity times need to be set.
        :param times: The times to set for the activity.
        :return: None
        """
        # Initialize a stack with the root node
        stack = [root]

        while stack:
            node = stack.pop()
            # Set the activity times for the current node
            node.activity.times = times
            for act in node.segment_activity.values():
                act.times = times

            # Add child nodes to the stack to process them iteratively
            if node.children:
                # Reverse the children to maintain traversal order
                stack.extend(reversed(node.children))

    def simplify_activity(self, root):
        """
        Iteratively simplifies the activity of each node starting from the root node.

        :param root: The root node whose activity needs to be simplified.
        :return: None
        """
        # Initialize a stack with the root node
        stack = [root]

        while stack:
            node = stack.pop()
            # Simplify the activity of the current node
            node.activity.simplify(self.simplification_epsilon)
            for act in node.segment_activity.values():
                act.simplify(self.simplification_epsilon)

            # Add child nodes to the stack to process them iteratively
            if node.children:
                # Reverse the children to maintain traversal order
                stack.extend(reversed(node.children))

    def import_group(self):
        self.node.import_groups_from_neuron([self])

    def remove_view(self):
        if self.view is not None:

            # Save any view changes
            # Except don't apply changes from an existing physics view
            if type(self.view) != VectorConfinerView:
                self.update_with_view_data()

            self.view.remove()

    def show(self, view_class=None, *args, **kwargs):
        if view_class is None:
            if self.interaction_granularity == 'Group':
                view_class = GroupObjectView

            if self.interaction_granularity == 'Cell':
                view_class = CellObjectView

            if self.interaction_granularity == 'Section':
                view_class = SectionObjectView

        if not hasattr(view_class, "show"):
            raise Exception(str(view_class) + ' does not implement show() method')

        # If there is an existing view, get any changes made in view, then remove view
        self.remove_view()

        # Show the new view
        try:
            registry = get_registry()
            with registry.transaction(), registry.import_batch():
                self.view = view_class(self, *args, **kwargs)
                self.view.show()  # already-iterative
        except Exception:
            self.view = None
            raise

        return self.view

    def update_with_view_data(self):
        if self.view is None:
            return

        if not hasattr(self.view, "update_group_with_view_data"):
            raise Exception(str(self.view.__class__) + ' does not implement update_group_with_view_data() method')

        from blenderneuron.blender.somadisplay import validate
        for container in getattr(self.view, 'containers', {}).values():
            validate(container.object)
        self.view.update_group_with_view_data()

    def add_to_UI(self):
        i = len(self.node.groups.keys())-1

        new_ui_group = self.node.ui_properties.groups.add()
        new_ui_group.name = self.name
        new_ui_group.index = i
        new_ui_group.selected = True

        # Highlight the UI group
        self.node.ui_properties.groups_index = i

        # Fill UI group list with not-selected root sections
        for root in self.node.root_index.values():
            # List all roots as available for selection in the group root UI list
            root.add_to_UI_group(new_ui_group)


    def remove(self):
        if self.view is not None:
            self.view.remove() # already-iterative

        # Remove the group roots from the group before deleting group
        self.select_roots('None')

        # remove group from the UI list
        self.remove_from_UI()

        # and from node
        self.node.groups.pop(self.name)

        # Remove color ramp material
        ramp_mat = self.color_ramp_material

        if ramp_mat is not None:
            ramp_mat.use_fake_user = False
            get_registry().remove(ramp_mat) # already-iterative

    def remove_from_UI(self):
        remove_prop_collection_item(self.node.ui_properties.groups, self.ui_group)

        self.node.ui_properties.groups_index = max(0, self.node.ui_properties.groups_index - 1)

    def add_groupless_roots(self):
        for root in self.node.root_index.values():
            if root.group is None:
                root.add_to_group(self)

    def select_roots(self, condition='All', pattern='*'):
        if condition == 'None':
            for root in list(self.roots.values()):
                if not fnmatch(root.name.lower(), pattern):
                    continue

                root.remove_from_group()

        else:
            for root in self.node.root_index.values():
                if not fnmatch(root.name.lower(), pattern):
                    continue

                if condition == 'All':
                    root.add_to_group(self)

                elif condition == 'Invert':
                    if root.group == self:
                        root.remove_from_group()
                    else:
                        root.add_to_group(self)



    def set_confiner_layers(self,
                            start_layer_object_name,
                            end_layer_object_name,
                            max_angle,
                            height_start,
                            height_end):

        self.highlight()

        start_layer = bpy.data.objects[start_layer_object_name]
        end_layer = bpy.data.objects[end_layer_object_name]

        settings = self.ui_group.layer_confiner_settings

        settings.start_mesh = start_layer
        settings.end_mesh = end_layer

        settings.max_bend_angle = max_angle
        settings.height_min = height_start
        settings.height_max = height_end

    def setup_confiner(self):
        self.highlight()

        self.show(VectorConfinerView)

    def confine_between_layers(self):
        self.highlight()

        if type(self.view) is VectorConfinerView:
            self.view.confine()

    def include_roots_by_name(self, names, exclude_others=False):
        names = set(names)

        for root in self.node.root_index.values():
            if root.name in names:
                root.add_to_group(self)

            else:
                if exclude_others and root.group is self:
                    root.remove_from_group()

    def to_file(self, file_name):
        self.update_with_view_data()

        group_dict = JsonView(self).show()

        dir = os.path.dirname(file_name)

        if dir != '' and not os.path.exists(dir):
            os.makedirs(dir)

        payload = serialize(group_dict)
        with open(file_name, 'w', encoding='utf-8') as f:
            f.write(payload)






