from blenderneuron.nrn.neuronnode import NeuronNode

BlenderNEURON = globals()["BlenderNEURON"] = NeuronNode()
