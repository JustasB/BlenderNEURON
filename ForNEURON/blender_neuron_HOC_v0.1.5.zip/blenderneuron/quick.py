from blenderneuron.client import BlenderNEURON

bn = BlenderNEURON()
